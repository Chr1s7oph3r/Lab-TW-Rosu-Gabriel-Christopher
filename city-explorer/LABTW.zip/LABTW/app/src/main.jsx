import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

// Toate importurile tale noi trebuie să fie aici, sus:
import { destinatii } from './data/destinatii.js'
import {
  getOrase, getNevizitate, totalZile, formatDestinatie, numarPeTara, sortDupaZile,
  marcheazaVizitat, adaugaDestinatie, stergeDestinatie
} from './utils/destinatii.js'
import { fetchUsers, fetchUserById } from './api/orase.js'

// Apoi vine logica de React:
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)

// ===== Laboratorul 2 =====
console.log('L2 Merge!')

// --- Exercițiul 1 ---
console.log('L2 Ex. 1 orașe:', getOrase(destinatii))
const nevizitate = getNevizitate(destinatii)
console.log('L2 Ex. 1 nevizitate:', nevizitate.length)
console.log('L2 Ex. 1 zile de vizitat:', totalZile(nevizitate))
console.log(destinatii.map(formatDestinatie).join('\n'))
console.log('L2 Ex. 1 pe țară:', numarPeTara(destinatii))
console.log('L2 Ex. 1 cea mai lungă vizită:', sortDupaZile(destinatii)[0].oras)

// --- Exercițiul 2 ---
const dupaMarcare = marcheazaVizitat(destinatii, '2') // Am pus id 2 pentru Monza
console.log('L2 Ex. 2 original:', destinatii[1].vizitat, ', listă nouă:', dupaMarcare[1].vizitat)
console.log('L2 Ex. 2 element refolosit:', destinatii[0] === dupaMarcare[0])

const circuitNou = { id: '7', oras: 'Interlagos', tara: 'Brazilia', zile: 4, vizitat: false }
const dupaAdaugare = adaugaDestinatie(destinatii, circuitNou)
console.log('L2 Ex. 2 după adăugare: original', destinatii.length, ', listă nouă', dupaAdaugare.length)

const dupaStergere = stergeDestinatie(dupaAdaugare, '7')
console.log('L2 Ex. 2 după ștergere:', dupaStergere.length)

// --- Exercițiul 3 ---
async function loadOrase() {
  try {
    const users = await fetchUsers()
    console.log('L2 Ex. 3 am primit', users.length, 'utilizatori')
    
    const oraseApi = users.map((user) => user.address.city)
    console.log('L2 Ex. 3 orașe:', oraseApi)
    
    const oraseLungi = oraseApi.filter((oras) => oras.length > 10)
    console.log('L2 Ex. 3 nume mai lungi de 10 caractere:', oraseLungi.length)
    
    const user1 = await fetchUserById(1)
    console.log('L2 Ex. 3 orașul utilizatorului 1:', user1.address.city)
    
  } catch (error) {
    console.error('L2 Ex. 3 nu am putut încărca datele:', error.message)
  }
}
loadOrase()