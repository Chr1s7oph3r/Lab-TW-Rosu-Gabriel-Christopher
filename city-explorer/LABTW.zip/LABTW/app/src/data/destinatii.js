export const destinatii = [
  { id: '1', oras: 'Monte Carlo', tara: 'Monaco', zile: 4, vizitat: true },
  { id: '2', oras: 'Monza', tara: 'Italia', zile: 3, vizitat: false },
  { id: '3', oras: 'Suzuka', tara: 'Japonia', zile: 5, vizitat: true },
  { id: '4', oras: 'Austin', tara: 'SUA', zile: 4, vizitat: false },
  { id: '5', oras: 'Spa', tara: 'Belgia', zile: 3, vizitat: false },
  { id: '6', oras: 'Silverstone', tara: 'Marea Britanie', zile: 4, vizitat: false } // Am adăugat unul în plus pentru a avea 6 elemente, ca în cerință
]